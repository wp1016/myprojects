import AV from "./av"

var APP_ID = 'N7xNLMGCDnx2WeU6Moh4Pfvi-gzGzoHsz';
var APP_KEY = 'E2TaFdtyLFFtpA1sOk2QwJL1';
export default AV.init({
  appId: APP_ID,
  appKey: APP_KEY
});
