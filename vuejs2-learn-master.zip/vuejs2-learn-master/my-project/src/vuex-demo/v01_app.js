//--file--- my-project\src\vuex-demo\v01_app.js

import Vue from 'vue'
import App from './v01.vue'

/* eslint-disable no-new */
new Vue({
  el: '#app',
  render: h => h(App)
})
