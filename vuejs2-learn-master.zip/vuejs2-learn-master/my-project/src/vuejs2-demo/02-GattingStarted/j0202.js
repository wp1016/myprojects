import Vue from 'vue'
import V0202 from './v0202.vue'

/* eslint-disable no-new */
new Vue({
  el: '#app',
  render: h => h(V0202)
})
