import Vue from 'vue'
import V0201 from './v0201.vue'

/* eslint-disable no-new */
new Vue({
  el: '#app',
  render: h => h(V0201)
})
