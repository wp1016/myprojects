<template>
  <div class="hello">
    <h1>{{ message }}</h1>
 </div>
</template>

<script>
export default {
  data () {
    return {
      message: '台湾小凡喜欢  Vue!感谢 vuejs qq群: 364912432'
    }
  }
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>
h1 {
  color: #42b983;
}
</style>
