<template>
    <div>
        456
    </div>
</template>
<script>
    export default {
        data () {
            return {
                msg: 'Welcome to Your Vue.js App'
            }
        }
    }
</script>
